INSERT INTO `users` (`id`, `username`, `password`, `level`) VALUES (1, 'admin', 'huza', 'admin');
INSERT INTO `users` (`id`, `username`, `password`, `level`) VALUES (2, 'ahmad', 'kasir', 'kasir');
INSERT INTO `users` (`id`, `username`, `password`, `level`) VALUES (3, 'anas', 'kasir', 'kasir');
