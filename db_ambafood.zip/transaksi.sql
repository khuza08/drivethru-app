INSERT INTO `transaksi` (`id_transaksi`, `tanggal`, `nama_kasir`, `metode_bayar`, `total_bayar`) VALUES (1057, '2025-06-18 10:57:04', 'ahmad', 'Tunai', 9130000.00);
INSERT INTO `transaksi` (`id_transaksi`, `tanggal`, `nama_kasir`, `metode_bayar`, `total_bayar`) VALUES (1058, '2025-06-18 10:58:04', 'ahmad', 'Tunai', 3300000.00);
INSERT INTO `transaksi` (`id_transaksi`, `tanggal`, `nama_kasir`, `metode_bayar`, `total_bayar`) VALUES (1059, '2025-06-18 10:59:02', 'ahmad', 'Tunai', 16500000.00);
INSERT INTO `transaksi` (`id_transaksi`, `tanggal`, `nama_kasir`, `metode_bayar`, `total_bayar`) VALUES (2219, '2025-06-16 22:19:23', 'ahmad', 'Tunai', 6930000.00);
INSERT INTO `transaksi` (`id_transaksi`, `tanggal`, `nama_kasir`, `metode_bayar`, `total_bayar`) VALUES (2224, '2025-06-16 22:24:53', 'ahmad', 'Tunai', 8250000.00);
INSERT INTO `transaksi` (`id_transaksi`, `tanggal`, `nama_kasir`, `metode_bayar`, `total_bayar`) VALUES (2323, '2025-06-16 23:23:47', 'ahmad', 'Tunai', 6160000.00);
INSERT INTO `transaksi` (`id_transaksi`, `tanggal`, `nama_kasir`, `metode_bayar`, `total_bayar`) VALUES (2331, '2025-06-17 23:31:04', 'anas', 'Tunai', 4730000.00);
INSERT INTO `transaksi` (`id_transaksi`, `tanggal`, `nama_kasir`, `metode_bayar`, `total_bayar`) VALUES (2347, '2025-06-16 23:47:29', 'anas', 'Tunai', 2200000.00);
