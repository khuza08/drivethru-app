INSERT INTO `kasir` (`id_kasir`, `username`, `password`) VALUES (3, 'ahmad', 'kasir');
INSERT INTO `kasir` (`id_kasir`, `username`, `password`) VALUES (4, 'anas', 'kasir');
